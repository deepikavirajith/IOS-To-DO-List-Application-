//
//  AppDelegate.h
//  To_Do_List
//
//  Created by student on 09/06/2020.
//  Copyright © 2020 student. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (readonly, strong) NSPersistentContainer *persistentContainer;


@property (readonly, nonatomic, strong)NSManagedObjectContext *manageContext;
@property (readonly, nonatomic, strong)NSManagedObjectModel *manageObjectModel;
@property (readonly, nonatomic, strong)NSPersistentStoreCoordinator *persistentStore;
-(NSURL *)applicationDocument;

- (void)saveContext;


@end

