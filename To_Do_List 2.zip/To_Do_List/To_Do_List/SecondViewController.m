//
//  SecondViewController.m
//  To_Do_List
//
//  Created by student on 09/06/2020.
//  Copyright © 2020 student. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

@synthesize nameText, descView, dataText, contactdb;



- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.contactdb)
    {
        [self.nameText setText:[self.contactdb valueForKey:@"name"]];
        [self.dataText setText:[self.contactdb valueForKey:@"data"]];
        [self.descView setText:[self.contactdb valueForKey:@"describe"]];
        
    }
    
}
-(NSManagedObjectContext *)manageContext
{
    
    NSManagedObjectContext *context = nil;
    _delegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    
     if([_delegate respondsToSelector:@selector(persistentContainer)]){
           context = _delegate.persistentContainer.viewContext;
       }
        
    return context;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)back_btn:(id)sender {
    
    //[self dismissViewControllerAnimated:YES completion:nil];
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)save_btn:(id)sender {
    
    NSManagedObjectContext *context = [self manageContext];
        
        if (self.contactdb) {
            
            [self.contactdb setValue:self.nameText.text forKey:@"name"];
            [self.contactdb setValue:self.descView.text forKey:@"describe"];
            [self.contactdb setValue:self.dataText.text forKey:@"data"];
            }
        else{
            if(nameText.text.length != 0 && descView.text.length != 0 && dataText.text.length !=0){
            //create new values
            NSManagedObject *newobject = [NSEntityDescription insertNewObjectForEntityForName:@"Works" inManagedObjectContext:context];
            [newobject setValue:nameText.text forKey:@"name"];
            [newobject setValue:descView.text forKey:@"describe"];
            [newobject setValue:dataText.text forKey:@"data"];
            }
            else{
                 UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please check all the fields" preferredStyle:UIAlertControllerStyleAlert];
                   UIAlertAction *alertAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){}];
                   [alert addAction: alertAction];
                   [self presentViewController:alert animated:YES completion:nil];            }
        }
       
        NSError *error = nil;
        if (![context save:&error]) {
            NSLog(@"Can't save %@ %@",error, [error localizedDescription]);
        }
  
    
        //[self dismissViewControllerAnimated:YES completion:nil];
    [self.navigationController popViewControllerAnimated:YES];
    }



@end
