//
//  ViewController.m
//  To_Do_List
//
//  Created by student on 09/06/2020.
//  Copyright © 2020 student. All rights reserved.
//

#import "ViewController.h"
#import "SecondViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize tableView, workarray;

-(NSManagedObjectContext *)manageContext{
    
    NSManagedObjectContext *context = nil;
    _delegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
     
    if([_delegate respondsToSelector:@selector(persistentContainer)]){
        context = _delegate.persistentContainer.viewContext;
    }
    return context;
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    //fetch the data
    NSManagedObjectContext *manageContext = [self manageContext];
    NSFetchRequest *fetchrequest = [[NSFetchRequest alloc]initWithEntityName:@"Works"];
    self.workarray = [[manageContext executeFetchRequest:fetchrequest error:nil]mutableCopy];
    //NSLog(@"%@", workarray);
    [self.tableView reloadData];
    //NSLog(@"%@", tableView);
    
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSManagedObjectContext *manageobjectcontext = [self manageContext];
    NSFetchRequest *fetchrequest = [[NSFetchRequest alloc]initWithEntityName:@"Works"];
    self.workarray = [[manageobjectcontext executeFetchRequest:fetchrequest
                                                         error:nil]mutableCopy];
    NSLog(@"%@", workarray);
    [self.tableView reloadData];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView reloadData];
    
   
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.workarray.count;
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
   static NSString *tableviewid = @"Cell";
    UITableViewCell *view = [tableView dequeueReusableCellWithIdentifier:tableviewid];
    if (view == nil) {
        view = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:tableviewid];
}
    [view.textLabel setText:[[self.workarray objectAtIndex:indexPath.row] valueForKey:@"name"]];
    [view.detailTextLabel setText:[[self.workarray objectAtIndex:indexPath.row] valueForKey:@"data"]];
    return view;
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return YES;
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSManagedObjectContext *context = [self manageContext];
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [context deleteObject:[self.workarray objectAtIndex:indexPath.row]];
        NSError *error = nil;
        if (![context save:&error]) {
            NSLog(@"Can't delete %@ %@", error, [error localizedDescription]);
            return;
        }
        [self.workarray removeObjectAtIndex:indexPath.row];
        [self.tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
    
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([[segue identifier]isEqualToString:@"viewCell"]){
        NSIndexPath *ind = [self.tableView indexPathForSelectedRow];
        NSManagedObject * selecteddevice = [self.workarray objectAtIndex:ind.row];

        SecondViewController *viewcontroller2 = segue.destinationViewController;
        viewcontroller2.contactdb = selecteddevice;
    }
}
    

@end
