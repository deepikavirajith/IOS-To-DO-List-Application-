//
//  SecondViewController.h
//  To_Do_List
//
//  Created by student on 09/06/2020.
//  Copyright © 2020 student. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "AppDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface SecondViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *nameText;
@property (weak, nonatomic) IBOutlet UITextField *dataText;
@property (weak, nonatomic) IBOutlet UITextField *descView;

- (IBAction)back_btn:(id)sender;
- (IBAction)save_btn:(id)sender;
@property(nonatomic, strong)AppDelegate *delegate;
@property(strong)NSManagedObject *contactdb;
@end

NS_ASSUME_NONNULL_END
