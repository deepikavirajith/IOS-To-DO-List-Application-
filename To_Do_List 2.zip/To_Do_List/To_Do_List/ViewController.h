//
//  ViewController.h
//  To_Do_List
//
//  Created by student on 09/06/2020.
//  Copyright © 2020 student. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (strong)NSMutableArray *workarray;
@property (strong, nonatomic)AppDelegate * delegate;

@end

